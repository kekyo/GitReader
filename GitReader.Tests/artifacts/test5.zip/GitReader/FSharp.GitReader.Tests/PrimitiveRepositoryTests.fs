﻿////////////////////////////////////////////////////////////////////////////
//
// GitReader - Lightweight Git local repository traversal library.
// Copyright (c) Kouji Matsui (@kozy_kekyo, @kekyo@mastodon.cloud)
//
// Licensed under Apache-v2: https://opensource.org/licenses/Apache-2.0
//
////////////////////////////////////////////////////////////////////////////

namespace GitReader.Primitive

open GitReader
open GitReader.Primitive
open NUnit.Framework
open System.Collections.Generic
open System.IO
open System.Text
open System.Threading.Tasks

type public PrimitiveRepositoryTests() =

    [<Test>]
    member _.GetCommitDirectly() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! commit = repository.getCommit(
            "1205dc34ce48bda28fc543daaf9525a9bb6e6d10") |> unwrapOptionAsy
        do! verify(commit)
    }

    [<Test>]
    member _.CommitNotFound() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! commit = repository.getCommit(
            "0000000000000000000000000000000000000000") |> unwrapOptionAsy
        do! verify(commit)
    }

    [<Test>]
    member _.GetCurrentHead() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! headref = repository.getCurrentHeadReference() |> unwrapOptionAsy
        let! commit = repository.getCommit(headref) |> unwrapOptionAsy
        do! verify(commit)
    }

    [<Test>]
    member _.GetBranchHead() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! headref = repository.getBranchHeadReference("master")
        let! commit = repository.getCommit(headref) |> unwrapOptionAsy
        do! verify(commit)
    }

    [<Test>]
    member _.GetRemoteBranchHead() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! headref = repository.getBranchHeadReference("origin/devel")
        let! commit = repository.getCommit(headref) |> unwrapOptionAsy
        do! verify(commit)
    }

    [<Test>]
    member _.GetTag() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! tagref = repository.getTagReference("2.0.0")
        let! tag = repository.getTag(tagref)
        do! verify(tag)
    }

    [<Test>]
    member _.GetTag2() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! tagref = repository.getTagReference("0.9.6")
        let! tag = repository.getTag(tagref)
        do! verify(tag)
    }

    [<Test>]
    member _.GetBranchHeads() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! branchrefs = repository.getBranchHeadReferences()
        do! verify(branchrefs |> Array.sortBy(fun br -> br.Name))
    }

    [<Test>]
    member _.GetRemoteBranchHeads() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! branchrefs = repository.getRemoteBranchHeadReferences()
        do! verify(branchrefs |> Array.sortBy(fun br -> br.Name))
    }
    
    [<Test>]
    member _.GetTags() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! tagrefs = repository.getTagReferences()
        let! tags = Task.WhenAll(
            tagrefs |>
            Seq.map (fun tagReference -> repository.getTag(tagReference) |> Async.StartImmediateAsTask))
        do! verify(tags |> Array.sortBy(fun t -> t.Name))
    }
     
    [<Test>]
    member _.GetTree() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! commit = repository.getCommit(
            "1205dc34ce48bda28fc543daaf9525a9bb6e6d10") |> unwrapOptionAsy
        let! tree = repository.getTree(commit.TreeRoot);
        do! verify(tree)
    }
     
    [<Test>]
    member _.OpenBlob() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! commit = repository.getCommit(
            "1205dc34ce48bda28fc543daaf9525a9bb6e6d10") |> unwrapOptionAsy
        let! tree = repository.getTree(commit.TreeRoot);
        let blob = tree.Children |> Seq.find (fun child -> child.Name = "build-nupkg.bat")
        use! blobStream = repository.openBlob blob.Hash
        let tr = new StreamReader(blobStream)
        do! verify(tr.ReadToEnd())
    }

    [<Test>]
    member _.TraverseBranchCommits() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! branchref = repository.getBranchHeadReference("master")
        let! commit = repository.getCommit(branchref) |> unwrapOptionAsy
        let mutable c = commit
        let mutable exit = false
        let commits = new List<PrimitiveCommit>();
        while not exit do
            commits.Add(c)
            // Bottom of branch.
            if c.Parents.Count = 0 then
                exit <- true
            else
                // Get primary parent.
                let primary = c.Parents.[0]
                let! commit = repository.getCommit(primary) |> unwrapOptionAsy
                c <- commit
        return! verify(commits.ToArray())
    }
        
    [<Test>]
    member _.GetStashes() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! stashes = repository.getStashes()
        return! verify(stashes |> Array.sortByDescending(fun stash -> stash.Committer.Date))
    }
    
    [<Test>]
    member _.GetHeadReflogs() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"))
        let! headRef = repository.getCurrentHeadReference()
        let! reflogs = repository.getRelatedReflogs(headRef.Value)
        return! verify(reflogs |> Array.sortByDescending(fun reflog -> reflog.Committer.Date))
    }
    
    [<Test>]
    member _.OpenRawObjectStream() = task {
        use! repository = Repository.Factory.openPrimitive(
            RepositoryTestsSetUp.getBasePath("test1"));
        use! result = repository.openRawObjectStream(
            "1205dc34ce48bda28fc543daaf9525a9bb6e6d10")
        let tr = new StreamReader(result.Stream, Encoding.UTF8, true)
        let! body = tr.ReadToEndAsync()
        return! verify((result.Type, body))
    }
